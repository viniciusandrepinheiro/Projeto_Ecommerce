
<section>

<?php
		require_once("cabecalho.php");
		require_once("conexao.php");

?>

<div class="container" id="quadro_usu">
<section>

<?php
$db = mysqli_select_db($conexao, "db_confeccao");   
$sql = mysqli_query($conexao,"select * from cliente") or die(mysqli_error($conexao));//para erro de consulta

//percorrendo os registro da  consulta


while($aux = mysqli_fetch_assoc($sql)){

echo "<article class='thumbnail'>";
	
	
echo "<p><i class='fa fa-tag' aria-hidden='true''>&nbsp; Id: ".$aux['id']."<br/></i></p>";
	
echo "<p><i class='fa fa-child' aria-hidden='true'>&nbsp; Nome: ".utf8_encode($aux['nome'])."<br/></i></p>";
	
echo "<p><i class='fa fa-inbox' aria-hidden='true'>&nbsp; Email: ".$aux['email']."<br/></i></p>";
	
//echo "Data de Nascimento: ".$aux['data']."<br/>";
	
echo "<p><i class='fa fa-map-pin' aria-hidden='true'>&nbsp; CPF: ".$aux['cpf']."<br/></i></p>";
	
echo "<p><i class='fa fa-phone' aria-hidden='true'>&nbsp Telefone: ".$aux['telefone']."<br/></i></p>";
	
echo "<p><i class='fa fa-paper-plane-o' aria-hidden='true'>&nbsp; CEP: ".$aux['cep']."<br/></i></p>";

echo "<p><i class='fa fa-flag-o' aria-hidden='true'>&nbsp; Estado: ".utf8_encode($aux['estado'])."<br/></i></p>";
	
echo "<p><i class='fa fa-thumb-tack' aria-hidden='true'>&nbsp; Cidade: ".utf8_encode($aux['cidade'])."<br/></i></p>";
	
	
echo "<p><i class='fa fa-map-marker' aria-hidden='true'>&nbsp; Endereço: ".utf8_encode($aux['endereco'])."<br/></i></p>";
	
echo "</article>";

}


?>

</section>
</div>



</body>
</html>