<?php
require_once("conexao.php");
if(isset($_POST["alterar"])){
foreach($_POST as $chave => $campos){
	$$chave	 = $campos;
	
if(empty($$chave)){
	$_SESSION["id"] = 1;//Campos em Branco
	header("location:perfilUsuario.php");
	die();
}

if($chave =="nome"){
	$nomeUsuario = $$chave;
	$nomeUsuario = strtolower($nomeUsuario);
	$nomeUsuario = strip_tags($nomeUsuario);
	$nomeUsuario = trim($nomeUsuario);
	$nomeUsuario = utf8_decode($nomeUsuario);	
	
}

if($chave == "email"){
if(strpos($$chave,"@")==0 && strpos($$chave,".com")==0){
		$_SESSION["id"] = 2;//Email Inválido
		header("location:cadastro.php");
		die();
}
else{
	$emailUsuario = $$chave;
	$busca = "SELECT id FROM usuario WHERE email='{$emailUsuario}'";
	$busca =  mysqli_query($conexao,$busca);
	$rows = mysqli_num_rows($busca);	
	if($rows == 1){
		$_SESSION["id"] = 2;//Email Inválido
		header("location:cadastro.php");
		die();
		}
	}
}

}

//ALTERAR NO BANCO DE DADOS
$alteracao = "UPDATE usuario SET nome ='{$nomeUsuario}' , email = '{$emailUsuario}' WHERE id=".$_SESSION["usuario"];

$resultado = mysqli_query($conexao,$alteracao);

if($resultado){
	$_SESSION["id"] = 3;//Alteracao Bem-Sucedida
	header("location:perfilUsuario.php");//Dados enviados com sucesso
	die();
}
else{
	$_SESSION["id"] = 4;//Alteracao Não Sucedida
	header("location:perfilUsuario.php");//Dados não enviados
	die();		
}

mysqli_close($conexao);
}
elseif(isset($_POST["deletar"])){

//DELETAR NO BANCO DE DADOS
$exclusao = "DELETE FROM usuario WHERE id=".$_SESSION["usuario"];

$resultado = mysqli_query($conexao,$exclusao);

if($resultado){
	$_SESSION["id"] = 3;//Alteracao Bem-Sucedida
	header("location:logout.php");//Dados enviados com sucesso
	die();
}


mysqli_close($conexao);

}