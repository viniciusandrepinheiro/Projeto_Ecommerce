<?php
require_once("cabecalho.php");
require_once("conexao.php");

if($_SESSION["logado"] != 1){
		 $_SESSION["falha"] = 1;
		 header("location:login.php");
		 die();
}

//Selecionar todos os campos no BD

$consulta = "SELECT * FROM filmes";
$busca = mysqli_query($conexao,$consulta);

//INICIO DO SISTEMA DE PAGINAÇÃO
//Pegando variavel da url, recebe pagina atual
$pagina = (isset($_GET['pagina']) && $_GET["pagina"]>0) ? $_GET["pagina"] : 1;

//Contar a quantidade de registros no banco
$totalRegistro = mysqli_num_rows($busca);

//Definir a quantidade de itens por página
$qtdPagina = 6;

//Calcular o número de páginas necessarias para apresentar os itens
$totalPagina = ceil($totalRegistro / $qtdPagina);//ceil() - Função que arredonda para cima

//Calcular o inicio da visualização, ou seja, a pagina 1 começa a mostrar os itens a partir do 1º item; a página 2 a partir do 4º item.....
$inicio = ($qtdPagina * $pagina) - $qtdPagina;

//Selecionar os itens a serem apresentados na página
$listaItem = "SELECT * FROM filmes LIMIT {$inicio}, {$qtdPagina}";

$resultadoItem = mysqli_query($conexao,$listaItem);

$qtdFinal = mysqli_num_rows($resultadoItem);

//Verificando página anterior e posterior

$pgAnterior = $pagina - 1;
$pgPosterior = $pagina + 1;

?>
<section id="bloco">
	<article class="container-fluid">
    	<?php
        	while($conteudo = mysqli_fetch_array($resultadoItem)){
				echo "<article class='col-md-4 col-sm-12'>";
					echo "<div class='box'>";
						echo "<h1>".ucwords(utf8_encode($conteudo["titulo"]))."</h1>";
						echo "<img src='{$conteudo['foto']}' alt='perfil' class='img-responsive'/>";
						echo "<strong>Ano: </strong>".$conteudo["ano"]."<br/>";
						echo "<strong>Duração: </strong>".$conteudo["duracao"]." min<br/>";
						echo "<p>".ucfirst(utf8_encode($conteudo["sinopse"]))."</p>";			
					echo "</div>";
				echo "</article>";
			}
			mysqli_close($conexao);
			
			//VERIFICANDO SE UMA PAGINA EXISTE OU NÃO
			if($pagina > $totalPagina){
				echo "<h1 class='erro'>Página Não Encontrada!</h1>";
			}
		?>
    </article>
    <article>
    	<nav class="text-center">
        	<ul class="pagination">
            	<li>
                <?php
                //DEFININDO A MARCAÇÃO DA PAGINAÇÃO
				if($pgAnterior != 0){
					echo "<a href='lista_dados.php?pagina={$pgAnterior}' title='Anterior'>";
					echo "<span class='glyphicon glyphicon-chevron-left'></span>";
					echo"</a>";	
				}
				else{
					echo "<a href='#' title='Anterior'>";
					echo "<span class='glyphicon glyphicon-chevron-left'></span>";
					echo"</a>";	
				}				
				?>
                </li>
                <?php
                	for($i = 1;$i <= $totalPagina; $i++){
						if($pagina == $i){
							echo "<li class='active'> <a href='lista_dados.php?pagina={$i}'>{$i}</a> </li>";	
						}
						else{
							echo "<li> <a href='lista_dados.php?pagina={$i}'>{$i}</a> </li>";	
						}
					}
				?>
                
                <li>
                 <?php
				if($pgPosterior <= $totalPagina){
					echo "<a href='lista_dados.php?pagina={$pgPosterior}' title='Proximo'>";
					echo "<span class='glyphicon glyphicon-chevron-right'></span>";
					echo"</a>";	
				}
				else{
					echo "<a href='' title='Proximo'>";
					echo "<span class='glyphicon glyphicon-chevron-right'></span>";
					echo"</a>";	
				}				
				?>
                </li>
            </ul>
        </nav>
    </article>
</section>
<?php require_once("footer.php"); ?>