<?php 
require_once("cabecalho.php"); 
require_once("conexao.php");

 
if(isset($_SESSION["id"])){
		if($_SESSION["id"] == 1){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Campos em Branco!</p>";	
		}	
		if($_SESSION["id"] == 2){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Email Inválido!</p>";	
		}		
		if($_SESSION["id"] == 6){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>".$_SESSION["msg_falha"]."</p>";	
		}
		unset($_SESSION["id"]);
	}
	
	
	if(isset($_SESSION["logado"]) && $_SESSION["logado"] == 0){
		echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>E-Mail ou Senha Errados</p>";	
		unset($_SESSION["logado"]);	
	}
	
	if(isset($_SESSION["falha"])){
		echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Você deve estar logado!</p>";	
	}
	unset($_SESSION["falha"]);
	

?>

<form action="validacao.php" method="post" id="formulario_login">
 
  	
  	
  	 <p class="titulo_formulario">Login</p>
  
  <input type="email" name="email" id="email" placeholder="Email" class="input_textual"/>
  
  <input type="password" name="senha" id="senha" placeholder="Senha" class="input_textual"/>
  
  <a href="#">Esqueceu sua Senha ?</a>
  
  <input type="submit" name="entrar" value="Entrar" class="input_boton fa fa-paper-plane" />
 
  
</form>
</body>
</html>
