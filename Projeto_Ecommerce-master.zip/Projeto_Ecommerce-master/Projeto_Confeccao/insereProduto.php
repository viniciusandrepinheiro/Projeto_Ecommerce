﻿<?php


require_once("conexao.php");

foreach($_POST as $chave => $campos){
	$$chave	 = $campos;
	
if(empty($$chave)){
	$_SESSION["id"] = 1;//Campos em Branco
	header("location:cadastrarProduto.php");
	die();
}

if($chave =="nome_produto"){
	$nome = $$chave;
	$nome = strtolower($nome);
	$nome = strip_tags($nome);
	$nome = trim($nome);
	$nome = utf8_decode($nome);	
	
}

if($chave =="descri"){
	$descri = $$chave;
	$descri= strtolower($descri);
	$descri = strip_tags($descri);
	$descri = trim($descri);
	$descri = utf8_decode($descri);	
	
}

if($chave =="valor"){
	$valor = $$chave;
	$valor= strtolower($valor);
	$valor = strip_tags($valor);
	$valor = trim($valor);
	$valor = utf8_decode($valor);	
	
}


}

$foto = $_FILES["foto"]["name"];
$foto_tmp = $_FILES["foto"]["tmp_name"];
	
	if(empty($foto)){
		$_SESSION["id"] = 10;
		header("location:cadastrarProduto.php");//imagem não enviada
		die();
	}
	else{
		$pasta = "imagem_produto/";
	
		//VERIFICANDO SE A PASTA EXISTE
		if(!file_exists($pasta)){
			mkdir($pasta,0777,true);
			
			$arquivo_final = $pasta.$foto;
			move_uploaded_file($foto_tmp, $arquivo_final);
			
		}
	
	else {
			$arquivo_final = $pasta.$foto;
			move_uploaded_file($foto_tmp, $arquivo_final);
		}
	
	}		

//-----------------INSERÇÃO NO BANCO-------------------------------->

$insercao = "INSERT INTO tb_produto VALUES('','{$nome}','{$descri}','{$valor}','{$arquivo_final}')";

$resultado = mysqli_query($conexao,$insercao);

if($resultado){
	$_SESSION["id"] = 4;
	header("location:cadastrarProduto.php");//Dados enviados
	die();	
}
else{
	$_SESSION["id"] = 3;
	header("location:cadastrarProduto.php");//Dados não enviados
	die();	
}

mysqli_close($conexao);