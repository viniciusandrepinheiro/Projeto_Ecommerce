<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body>
<?php
require_once("conexao.php");

	if($_SESSION["logado"] !=1){
			$_SESSION["falha"]=1;
			header("location: login.php");
			die();
			
			}
?>        
       
 	<form action="css/valida.php" method="post">
            <div class="seta_1"></div>
            <div class="seta_2"></div>
                <label for="usuario">Usuário</label>
                <input type="text" name="usuario" placeholder="Informe seu usuário" id="usuario" class="caixa"/> <br/>
                
                <label for="senha">Senha</label>
                <input type="password" name="senha" placeholder="Informe sua senha" id="senha" class="caixa"/> <br/>
                
                <input type="submit" value="Entrar" />
            </form>




</body>
</html>