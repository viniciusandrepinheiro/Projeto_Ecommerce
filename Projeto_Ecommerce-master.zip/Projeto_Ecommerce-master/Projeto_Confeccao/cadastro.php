
<?php require_once("cabecalho.php");?>

<section id="formulario2">

<form action="insere.php" method="post">
    
<?php
	if(isset($_SESSION["id"])){
		if($_SESSION["id"] == 1){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Campos em Branco!</p>";	
		}	
		if($_SESSION["id"] == 2){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Email Inválido ou Já Registrado!</p>";	
		}
		if($_SESSION["id"] == 3){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Erro ao Cadastrar!</p>";	
		}
		if($_SESSION["id"] == 4){
			echo "<p class='sucesso'><i class='fa fa-check'>&nbsp;</i>Cadastrado com Sucesso!</p>";	
		}
		if($_SESSION["id"] == 5){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>".$_SESSION["msg_falha"]."</p>";	
		}
		unset($_SESSION["id"]);
	}
?>			
       	 	<fieldset>
       	 		<div id="div_form2" class="container visible">
        	 <legend id="legend2"><img src="img/Cadastro.png" class="nomequeficaemcimadoscoisaaqui" alt=""></legend>
             
             <label for="nome">Nome:</label><br/>
             <input type="text" name="nome" id="nome" autofocus/><br/>
                         
             <label for="email">Email:</label><br/>
             <input type="email" name="email" id="email"/><br/>

        	<label for="senha">Senha:</label><br/>
            <input type="password" name="senha" id="senha"/><br/>
            	<div class="caixaAjuda">
       <br/>
           <input type="submit" value="Enviar" name="enviar" class="botao bt" />
           <input type="reset" value="Limpar" name="limpar" class="botao bt"/>
           <p id="link">Já tem conta? <a href="login.php">Faça Login</a></p>
           </div>
           </div>
        </fieldset>
    </form>
</section>
<img id="banner2_2" src="img/Banner2.png" alt="pipoca">

<?php require_once("footer.php"); ?>
