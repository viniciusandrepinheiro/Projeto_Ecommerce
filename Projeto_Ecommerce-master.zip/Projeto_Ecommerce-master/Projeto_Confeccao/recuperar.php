<?php
require_once("conexao.php");
foreach($_POST as $chave => $campos){
	$$chave	 = $campos;
	
if(empty($$chave)){
	$_SESSION["id"] = 1;//Campos em Branco
	header("location:recuperarSenha.php");
	die();
}

if($chave == "email"){
if(strpos($$chave,"@")==0 && strpos($$chave,".com")==0){
		$_SESSION["id"] = 4;//Email Inválido
		header("location:recuperarSenha.php");
		die();
}
else{
	$emailUsuario = $$chave;	
}
}

if($chave == "senha"){
$novaSenha = md5($$chave);
}

}

//ALTERAR NO BANCO DE DADOS
$alteracao = "UPDATE usuario SET senha ='{$novaSenha}' WHERE email ='{$emailUsuario}'";

$resultado = mysqli_query($conexao,$alteracao);

if($resultado){
	$_SESSION["id"] = 3;//Alteracao Bem-Sucedida
	header("location:recuperarSenha.php");//Dados enviados com sucesso
	die();
}
else{
	$_SESSION["id"] = 4;//Alteracao Não Sucedida
	header("location:recuperarSenha.php");//Dados não enviados
	die();		
}

mysqli_close($conexao);

