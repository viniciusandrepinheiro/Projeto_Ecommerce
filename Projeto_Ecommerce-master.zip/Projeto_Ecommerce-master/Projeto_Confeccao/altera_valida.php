<?php
require_once("conexao.php");


if(isset($_POST['alterar_nome'])){
	
	$novo_nome = $_POST['novo_nome'];
	
	if(empty($novo_nome)){
		$_SESSION['id'] = 4;
		header("location: perfilCliente.php");
		die();
	}
	else{
	$novo_nome = utf8_decode($novo_nome);	

	$novo_nome= strtolower($novo_nome);
	$novo_nome = strip_tags($novo_nome);
	$novo_nome = trim($novo_nome);
		
	$altera = "update cliente SET nome='{$novo_nome}' where id=".($_SESSION['usuario']);
				$_SESSION['id'] = 11;
	$resultado_altera = mysqli_query($conexao,$altera);
				header("location: perfilCliente.php");
				die();	
		
	}
	
}