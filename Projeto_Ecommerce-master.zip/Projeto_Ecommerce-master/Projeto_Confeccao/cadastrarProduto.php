﻿<?php
		require_once("cabecalho.php");
		require_once("conexao.php");

?>


<form id="formulario_produto" action="insereProduto.php" method="post" enctype="multipart/form-data" class="">
<?php
	if(isset($_SESSION["id"])){
		if($_SESSION["id"] == 1){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Campos em Branco!</p>";	
		}		
		
		if($_SESSION["id"] == 6){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Dados não Enviados</p>";	
		}		
		if($_SESSION["id"] == 4){
			echo "<p class='sucesso'><i class='fa fa-check'>&nbsp;</i>Cadastrado com Sucesso!</p>";	
		}
		if($_SESSION["id"] == 10){
			echo "<p class='erro'><i class='fa fa-check'>&nbsp;</i>Foto não enviada!</p>";	
		}
		unset($_SESSION["id"]);
	}		

?>			
		<fieldset>
        <h4>Cadastro de Produto</h4>
        <label>Nome do produto:</label>
        <br/>
        <input type="text" name="nome_produto"/>
        <br/>
        
        <label>Descrição:</label>
        <br/>
        <textarea name="descri"></textarea>
        <br/>
        
        <label>Valor :</label>
        <br/>
        <input type="number" name="valor"/>
        <br/>
        <label>Imagem do Produto:</label>
        <br/>
        <input type="file" name="foto"/>
        <br/>
        
        <input class="botao btm" type="submit" name="enviar" value="Enviar"/>
        
         <input class="botao" type="reset"  value="Limpar"/>

        </fieldset>


</form>
</div>
</body>
</html>

