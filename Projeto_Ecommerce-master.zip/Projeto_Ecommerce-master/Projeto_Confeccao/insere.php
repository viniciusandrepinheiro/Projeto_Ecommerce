<?php
require_once("conexao.php");

foreach($_POST as $chave => $campos){
	$$chave	 = $campos;
	
if(empty($$chave)){
	$_SESSION["id"] = 1;//Campos em Branco
	header("location:cadastro.php");
	die();
}

if($chave =="nome"){
	$nomeUsuario = $$chave;
	$nomeUsuario = strtolower($nomeUsuario);
	$nomeUsuario = strip_tags($nomeUsuario);
	$nomeUsuario = trim($nomeUsuario);
	$nomeUsuario = utf8_decode($nomeUsuario);	
	
}

if($chave == "email"){
if(strpos($$chave,"@")==0 && strpos($$chave,".com")==0){
		$_SESSION["id"] = 2;//Email Inválido
		header("location:cadastro.php");
		die();
}
else{
	$emailUsuario = $$chave;
	$busca = "SELECT id FROM usuario WHERE email='{$emailUsuario}'";
	$busca =  mysqli_query($conexao,$busca);
	$rows = mysqli_num_rows($busca);	
	if($rows == 1){
		$_SESSION["id"] = 2;//Email Inválido
		header("location:cadastro.php");
		die();
		}
	}
}

if($chave == "senha"){
	$senhaUsuario = md5($$chave);
}

}

//-----------------INSERÇÃO NO BANCO-------------------------------->

$insercao = "INSERT INTO usuario VALUES('','{$nomeUsuario}','{$emailUsuario}','{$senhaUsuario}')";

$resultado = mysqli_query($conexao,$insercao);

if($resultado){
	$_SESSION["id"] = 4;
	header("location:cadastro.php");//Dados enviados
	die();	
}
else{
	$_SESSION["id"] = 3;
	header("location:cadastro.php");//Dados não enviados
	die();	
}

mysqli_close($conexao);