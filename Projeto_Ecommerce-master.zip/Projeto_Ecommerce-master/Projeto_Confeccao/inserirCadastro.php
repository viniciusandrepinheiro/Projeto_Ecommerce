<?php
require_once("conexao.php");

foreach($_POST as $chave=>$campos){
	$$chave	= $campos;
	

	if(empty($$chave)){
		$_SESSION["id"] = 1;//Campos em Branco
		header("location:cadastrarCliente.php");
		die();
	}
	
	if($chave == "email"){
		$email = $$chave;	
		if(strpos($email,"@")==0 || strpos($email,".com")==0){
		$_SESSION["id"] = 2;//Email Inválido
		header("location:login.php");
		die();
	}
}

	if($chave =="senha"){
		$senha = md5($senha);;
		}


	if($chave!="sexo"){
		
		$$chave = utf8_decode($$chave);
		 $$chave = strtolower($$chave);//Retornando minusculo
		 $$chave = trim($$chave);
		 $$chave = strip_tags($$chave);
		 $$chave = str_replace(array("'","\""),"",$$chave);//retirar aspas simples e aspas duplas


		 }
	}
	

//-----------------INSERÇÃO NO BANCO-------------------------------->
$insercao = "INSERT INTO cliente VALUES('','{$nome}','{$email}','{$senha}','{$sexo}','{$data}','{$cpf}','{$telefone}','{$estado}','{$cidade}','{$cep}','{$endereco}')";

$resultado = mysqli_query($conexao,$insercao);

if($resultado){
	$_SESSION["id"] = 9;
	header("location:cadastrarCliente.php");//Dados enviados
	die();	
}
else{
	$_SESSION["id"] = 6;
	header("location:cadastrarCliente.php");//Dados não enviados
	die();	
}

mysqli_close($conexao);