<?php require_once("cabecalho.php");?>

<section id="formulario">


<form action="recuperar.php" method="post">
    	<fieldset>
<?php
	if(isset($_SESSION["id"])){
		if($_SESSION["id"] == 1){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Campos em Branco!</p>";	
		}	
		if($_SESSION["id"] == 2){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Email Inválido!</p>";	
		}
		if($_SESSION["id"] == 3){
			echo "<p class='sucesso'><i class='fa fa-check'>&nbsp;</i>Senha Alterada!</p>";	
		}		
		if($_SESSION["id"] == 6){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>".$_SESSION["msg_falha"]."</p>";	
		}
		unset($_SESSION["id"]);
	}

?>			<div class="div_form">
           <legend>Recuperacão</legend>
           <label id="labelemail" for="email">Email:</label>
           <input type="email" name="email" id="email" autofocus/><br/>
           <label for="senha">Nova Senha:</label>
           <input type="password" name="senha" id="senha">
           <br/>
           <div class="caixaAjuda">
           <input type="submit" value="Salvar" name="salvar" class="botao bt" />
           <input type="reset" value="Limpar" name="limpar" class="botao bt"/>
           </fieldset>
           </div>
    		</div>

    
    </form>
    
<?php require_once("footer.php"); ?>