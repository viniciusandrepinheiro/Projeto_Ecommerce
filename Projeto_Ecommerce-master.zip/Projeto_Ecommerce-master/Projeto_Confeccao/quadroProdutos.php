<section>

<?php
		require_once("cabecalho.php");
		require_once("conexao.php");

?>

<div class="container " id="quadro_produto">
<section>

<?php
$db = mysqli_select_db($conexao, "db_confeccao");   
$sql = mysqli_query($conexao,"select * from tb_produto") or die(mysqli_error($conexao));//para erro de consulta

//percorrendo os registro da  consulta


while($aux = mysqli_fetch_assoc($sql)){

echo "<article class='thumbnail text-center'>";
	
echo "<img src='{$aux['foto_produto']}' class='foto_produto'><br/><br/>";
	
	
echo "<p><i class='fa fa-tag' aria-hidden='true''>&nbsp; Id: ".$aux['id']."<br/></i></p>";
	
echo "<p><i class='fa fa-child' aria-hidden='true'>&nbsp; Nome: ".utf8_encode($aux['nome_produto'])."<br/></i></p>";
	
echo "<p><i class='fa fa-list-alt' aria-hidden='true'>&nbsp; Descrição: ".utf8_encode($aux['descricao_produto'])."<br/></i></p>";

echo "<p><i class='fa fa-money' aria-hidden='true'>&nbsp; Valor: ".($aux['valor_produto'])."<br/></i></p>";

	
echo "</article>";

}


?>

</section>
</div>

	</body>
</html>
