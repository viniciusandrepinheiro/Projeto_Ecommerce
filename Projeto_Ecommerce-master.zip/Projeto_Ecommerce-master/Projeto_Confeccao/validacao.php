<?php
require_once("conexao.php");

foreach($_POST as $chave => $campos){
$$chave = $campos;
	
	
if(empty($$chave)){
	$_SESSION["id"] = 1;
	header("location:login.php");
	die();
}

if($chave == "email"){
	$email = $$chave;	
	if(strpos($email,"@")==0 || strpos($email,".com")==0){
	$_SESSION["id"] = 2;//Email Inválido
	header("location:login.php");
	die();
	}
}
		
	
	if($chave == "senha"){

		$senha = md5($_POST["senha"]);
		}
	
}

$consulta = mysqli_query($conexao,"SELECT id FROM cliente WHERE email = '{$email}' and senha = '{$senha}'");

$rows = mysqli_num_rows($consulta);

if($rows == 1){
	$linha = mysqli_fetch_array($consulta);
	$_SESSION["logado"] = 1;
	$_SESSION["usuario"] = $linha["id"];
	header("location:index.php");
	//header("location:perfilCliente.php");

	die();
}
else
	{
	$_SESSION["logado"]=0;
	header("location:login.php");
	die();
	}
	
	
mysqli_close($conexao);