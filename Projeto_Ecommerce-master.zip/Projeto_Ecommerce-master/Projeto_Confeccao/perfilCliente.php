<?php 
require_once("cabecalho.php");
require_once("conexao.php");
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>


</head>

<body>

<?php
	
$busca = mysqli_query($conexao,"SELECT nome,email,cpf,telefone,estado,cidade,cep,endereco FROM cliente WHERE id=".$_SESSION["usuario"]);
	$rows = mysqli_num_rows($busca);
	
	if($rows == 1){
		$dados = mysqli_fetch_array($busca);
		$nome =utf8_encode(ucwords($dados["nome"]));
		$email = $dados["email"];
		$cpf = $dados["cpf"];
		$telefone = $dados["telefone"];
		$estado = utf8_encode(ucwords($dados["estado"]));
		$cidade = utf8_encode(ucwords($dados['cidade']));
		$cep = $dados["cep"];
		$endereco = utf8_encode(ucwords($dados['endereco']));
		
	}

?>


<section id="secao_dados">
<h4 class="dados">Seus Dados:</h4>
<ul >
	<li>Nome: <?=$nome?></li>
	<li>Email: <?=$email?></li>
	<li>CPF: <?=$cpf?></li>
	<li>Telefone: <?=$telefone?></li>
	<li>Estado: <?=$estado?></li>
	<li>Cidade: <?=$cidade?></li>
	<li>CEP: <?=$cep?></li>
	<li>Endereco: <?=$endereco?></li>
</ul>	
	
</section>


	<a class="alterar" data-toggle='modal' data-target='#myModal'>PARA ALTERAR</a>
	
	
  
  		<div class='modal fade' id='myModal' role='dialog'>
		<div class='modal-dialog modal-lg'>
    	<div class='modal-content'>
    	
		<div class='modal-body'>
		
		<?php if(isset($_SESSION["id"])){
			if($_SESSION["id"]==4){
				echo "<p class='erro'>Campos em branco</p>";
				}
			elseif($_SESSION["id"]==11){
				echo "<p class='sucesso'>Dados enviados com sucesso !</p>";
				header("location: perfilCliente.php");
				die();
			}
		}
		unset($_SESSION['id']);
	
	?>
		<form id="form_altera" action="altera_valida.php" method="post"/>	
		
		<label>Nome:</label><br/>
		<input type="text" name="novo_nome" />
		<input type="submit" name="alterar_nome"/>
		
		<p></p>
		
		
		<label>Email:</label><br/>
		<input type="email" name="novo_email" />
		<input type="submit" name="alterar_email"/>
		
		<p></p>
		
		
		<label>CPF:</label><br/>
		<ul>
			OBS: CPF ÚNICO*
			<li>
				
				<?=$cpf?>
			</li>
		</ul>
		
		<p></p>
		
		
		<label>Telefone:</label><br/>
		<input type="text" name="novo_telefone" />
		<input type="submit" name="alterar_telefone"/>
		
		<p></p>
		
		
		
		<label>Estado:</label><br/>
		<input type="text" name="novo_estado" />
		<input type="submit" name="alterar_estado"/>
		
		<p></p>
		
		<label>Cidade:</label><br/>
		<input type="text" name="novo_cidade" />
		<input type="submit" name="alterar_cidade"/>
		
		<p></p>
		
		<label>CEP:</label><br/>
		<input type="text" name="novo_cep" />
		<input type="submit" name="alterar_cep"/>
		
		<p></p>
		
		
		<label>Endereço:</label><br/>
		<input type="text" name="novo_endereco" />
		<input type="submit" name="alterar_endereco"/>
		
		<p></p>
		</form>	
   		
		
    	</div>
		
    </div>
	</div>
    </div>
   


</body>
</html>