<?php require_once("cabecalho.php");require_once("conexao.php")?>

<div>
		
		<h1><a href="cadastrarCliente.php">CADASTRA-SE</a></h1>
</div>




	<footer class="text-center link_rodape">

		<div class="container">		
				<div class="row ">
						
						<h3 class="titulo">Categorias</h3>
						<hr class="traco"/>
				</div>
			<div class="col-md-4">
				<ul>
					<h4>Roupas</h4>
					<li><a href="#">Camisas</a></li>
					<li><a href="#">Calças</li>
				</ul>
			</div>
			<div class="col-md-4 ">
				<ul>
					<h4>Calçados</h4>
					<li><a href="#">Masculino</a></li>			
					<li><a href="#">Femenino</a></li>
				</ul>
			</div>
			<div class="col-md-4">
				<ul>
					<h4>Boné</h4>
					<li><a href="#">Unissex</a></li>
				</ul>
			</div>
			
		</div>

	</footer>
	
	<br/>
	
	<div class="hel">		
		<div class="container">		
			<div class="row ">
				<div class="col-sm-3">
					
				</div>
				
					<div class="col-sm-6">
						<p class="info">Rua Fernando Abott, 174 - CEP: 96810-072 - São Luís - MA</p>
						<p class="info">Fone/Fax: (98) 3333-3333 - bev@live.com</p>
					</div>
				
				

			</div>	
		</div>
	</div>

	




</body>	
</html>
