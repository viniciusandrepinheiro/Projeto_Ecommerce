
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>E-commerce</title>
<link rel="stylesheet" type="text/css" href="css/estilo.css"/>
<link rel="stylesheet" type="text/css" href="css/login.css"/>

<link rel="stylesheet" href="font-awesome-4.4.0/css/font-awesome.css">

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css"/>

<!--<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>-->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>


<div class="container">
		<div class="row">
			<div class="col-sm-12">
			<header>
					<a href="index.php"><img class="logo" src="imagem/bev_logo.png" alt="logo"/></a>

			<nav id="menu" class="navbar-fixed ">
				<ul>
					<li><a href="#">Produtos</a></li>
					<li><a href="carrinho.php">Carrinho</a></li>
<?php
		require_once("conexao.php");
		
    	 if(isset($_SESSION["logado"]) && $_SESSION["logado"] == 1){
		 
		 if(isset($_SESSION["usuario"]) && $_SESSION["usuario"] == 1){
		 echo "<li><a href='cadastrarProduto.php'>Cadastrar Produto&nbsp; <i class='fa fa-plus'></i></a></li>"; 
			echo " <li><a href='quadroClientes.php'>Quadro de Usuários </a></li>";		
			echo " <li><a href='quadroProdutos.php'>Quadro de Produtos </a></li>";


		 }
		  echo "<li><a href='perfilCliente.php'>Perfil &nbsp;<i class='fa fa-user'></i></a></li>";

		 echo " <li><a href='logout.php'>Sair &nbsp;<i class='fa fa-sign-out'></i></a></li>";


		 }
		 else{
			 echo "<li><a href='login.php'>Login <i class='fa fa-sign-in'></i></a></li>";


		}
					
			
					
					
		 
?>
				</ul>
			
		
			</nav>
			</header>

		</div>
	</div>
</div>




<body>
	


 
