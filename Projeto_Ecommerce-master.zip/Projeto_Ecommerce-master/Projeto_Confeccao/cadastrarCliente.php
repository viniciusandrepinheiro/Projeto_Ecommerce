<?php require_once("cabecalho.php");?>

<section id="formulario">


  <form action="inserirCadastro.php" method="post" id="">

<?php
	if(isset($_SESSION["id"])){
		if($_SESSION["id"] == 1){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Campos em Branco!</p>";	
		}		
		if($_SESSION["id"] == 2){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Ano Inválido</p>";	
		}	
		if($_SESSION["id"] == 6){
			echo "<p class='erro'><i class='fa fa-warning'>&nbsp;</i>Dados não Enviados</p>";	
		}		
		if($_SESSION["id"] == 9){
			echo "<p class='sucesso'><i class='fa fa-check'>&nbsp;</i>Cadastrado com Sucesso!</p>";	
		}
		if($_SESSION["id"] == 10){
			echo "<p class='erro'><i class='fa fa-check'>&nbsp;</i>Data inválida!</p>";	
		}
		unset($_SESSION["id"]);
	}		

?>	
    	<fieldset>
		   <div id="div_form_add"> 
           <legend>CADASTRO</legend>
           
           <label for="nome" id="nome">Nome:</label>
           <input type="text" name="nome" id="nome" autofocus placeholder="Ex:João Silva"/>
          
            <br/>
           
 		   <label for="email">Email:</label>
           <input type="email" name="email" id="email" placeholder="email@email.com"/>
           <br/>
           
            <label id="senha" for="senha">Senha:</label>
		  <input type="password" name="senha"/>
          
          <br/>
          
         <label for="sexo">Sexo:</label>
           		<select name="sexo" id="sexo">
                	<option value="">Escolha...</option>
                	<option value="masculino">Masculino</option>
               		<option value="femenino">Femenino</option>
                </select>
              
        	<br/>  
          
          
         <label id="data" for="data" >Nascimento:</label>
          
           <input type="text" name="data" id="data" placeholder="dd/mm/aaaa"/>
         
         
           
            <br/>
            
                       
           
           <br/>
         
           <label  for="cpf"> CPF:</label>
		  <input type="text" name="cpf"  id="cpf" placeholder="000.000.006-00"/>
        
            <br/>
         
           <label for="telefone">Telefone:</label>
           <input type="text" name="telefone" id="telefone" placeholder="(DDD) 9XXXX-XXXX"/>
           
           
            <br/>
         
           <label for="estado">Estado:</label>
           <input type="text" name="estado" id="estado" placeholder="Ex:Maranhão"/>
           
            <br/>
            
            <label for="cidade">Cidade:</label>
           <input type="text" name="cidade" id="cidade" placeholder="São Luís"/>
           
            <br/>
         
           <label for="cep">CEP:</label>
           <input type="text" name="cep" id="cep" placeholder="65058-890"/>
           
           
            <br/>
         
           <label for="endereco">Endereço:</label>
           <input type="text" name="endereco" id="endereco" placeholder="Rua Sete de Setembro"/>
         
 			<br/>
       		<br/>
        	<input type="submit" name="enviar" value="Finalizar" class="btm_finalizar botao_finalizar"/>        
         
           </fieldset>
           	</div>
           </div>
    </form>
    	
  </body>
 </html>