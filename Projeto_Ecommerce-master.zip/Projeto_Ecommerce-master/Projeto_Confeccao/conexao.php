<?php

session_start();

$conexao = mysqli_connect("localhost","root","","db_confeccao");


if(!$conexao){
	echo "Conexão Inválida !";
	echo "<br/>".mysqli_connect_error()."<br/>";
	die();
}
